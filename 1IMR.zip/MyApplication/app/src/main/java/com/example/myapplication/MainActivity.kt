package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var txt:EditText;
    lateinit var button: Button;


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txt=findViewById(R.id.editTextText)
        button=findViewById(R.id.button)
        button.setOnClickListener {
            Toast.makeText(this,"El usuario ha puesto esta chuminada: ${txt.text}", Toast.LENGTH_LONG).show()

        }
    }
}