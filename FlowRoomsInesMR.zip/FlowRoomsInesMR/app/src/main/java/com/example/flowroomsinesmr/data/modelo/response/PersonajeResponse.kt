package com.example.flowroomsinesmr.data.modelo.response

import com.example.flowroomsinesmr.data.modelo.entity.PersonajeEntity

class PersonajeResponse (
    val results: PersonajeEntity?
)