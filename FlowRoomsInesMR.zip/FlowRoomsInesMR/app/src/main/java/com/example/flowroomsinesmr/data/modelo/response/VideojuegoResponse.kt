package com.example.flowroomsinesmr.data.modelo.response

import com.example.flowroomsinesmr.data.modelo.entity.VideojuegoEntity

class VideojuegoResponse(
    val results: VideojuegoEntity?
)