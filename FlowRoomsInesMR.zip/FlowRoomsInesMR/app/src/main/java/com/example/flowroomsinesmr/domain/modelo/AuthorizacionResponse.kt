package com.example.flowroomsinesmr.domain.modelo


data class AuthorizacionResponse (
    val accessToken: String? = null,
    val refreshToken: String? = null,
)