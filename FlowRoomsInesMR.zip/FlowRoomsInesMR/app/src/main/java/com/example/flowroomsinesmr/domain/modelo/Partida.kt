package com.example.flowroomsinesmr.domain.modelo

data class Partida (
    val id: Int,
    val puntuacion: Int
)



