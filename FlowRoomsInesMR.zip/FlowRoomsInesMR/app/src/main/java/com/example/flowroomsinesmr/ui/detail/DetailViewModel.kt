package com.example.flowroomsinesmr.ui.detail

class DetailViewModel {
}