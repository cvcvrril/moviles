package com.example.flowroomsinesmr.ui.detail.adapters

class JugadorAdapter {
}