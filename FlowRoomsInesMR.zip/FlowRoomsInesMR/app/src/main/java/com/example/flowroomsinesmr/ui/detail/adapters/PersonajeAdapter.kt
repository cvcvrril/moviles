package com.example.flowroomsinesmr.ui.detail.adapters

class PersonajeAdapter {
}