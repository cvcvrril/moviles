package com.example.flowroomsinesmr.ui.detail.fragments

class DetailListPartidaFragment {
}