package com.example.flowroomsinesmr.ui.detail.fragments

import androidx.fragment.app.Fragment
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class DetailListPersonajeFragment : Fragment(){

}