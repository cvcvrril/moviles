package com.example.flowroomsinesmr.ui.detail.fragments

import androidx.fragment.app.Fragment

class DetailListPersonajesFragment : Fragment() {
}