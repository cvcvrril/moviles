package com.example.flowroomsinesmr.ui.detail.viewmodels

class DetailJugadorViewModel {
}