# TODOs:

### General

* Montar pantalla login
* Montar pantalla registro
* Montar pantalla detalle
* Montar pantalla add
* Arreglar splash screen

### GraphQL

* Montar método delete
* Montar método add
* Montar método update

### Seguridad

* Montar métodos para capturar los tokens
* Captura de las excepciones