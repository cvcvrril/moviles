package com.example.aprobarines.data.modelo.request

data class AuthorizationRequest(
    val username: String,
    val password: String
) {
}