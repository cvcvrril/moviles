package com.example.aprobarines.data.modelo.response


data class AuthorizacionResponse (
    val accessToken: String? = null,
    val refreshToken: String? = null,
)