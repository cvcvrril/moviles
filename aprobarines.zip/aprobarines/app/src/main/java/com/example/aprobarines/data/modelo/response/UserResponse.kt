package com.example.aprobarines.data.modelo.response

data class UserResponse(
    val user: String,
    val password: String,
) {
}