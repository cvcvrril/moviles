package com.example.aprobarines.domain.modelo

data class Personaje (
    val id: Int,
    val nombre: String,
    val descripcion: String,
){
}