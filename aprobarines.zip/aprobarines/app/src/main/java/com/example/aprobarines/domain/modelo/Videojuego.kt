package com.example.aprobarines.domain.modelo

data class Videojuego (
    val id: Int,
    val titulo: String,
    val descripcion: String,
){}