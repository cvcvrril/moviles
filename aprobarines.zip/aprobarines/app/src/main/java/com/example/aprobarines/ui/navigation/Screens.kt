package com.example.composefullequip.ui.navigation





val screensBottomBar = listOf(
    Screens("videojuegos"),
    Screens("personajes"),
)

data class Screens(val route: String) {

}
