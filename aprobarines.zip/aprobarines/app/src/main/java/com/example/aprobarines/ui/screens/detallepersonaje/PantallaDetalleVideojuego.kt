package com.example.composefullequip.ui.screens.detalle

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun PantallaDetalleVideojuego(
    videojuegoId: String
) {

    Text("Pantalla Detalle Videojuego ${videojuegoId}" )
    
}