package com.example.practicaexamenmoviles.framework.fragmentsPersonaje

import androidx.fragment.app.Fragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ImagenPersonajeFragment : Fragment() {




}