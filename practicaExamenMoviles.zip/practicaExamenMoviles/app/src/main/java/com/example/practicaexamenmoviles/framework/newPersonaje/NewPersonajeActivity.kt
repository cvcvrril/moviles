package com.example.practicaexamenmoviles.framework.newPersonaje

import androidx.appcompat.app.AppCompatActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class NewPersonajeActivity : AppCompatActivity() {
}